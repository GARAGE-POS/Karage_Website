using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace Karage_Website.Views.MarketPlace
{
    public class MarketPlaceModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
