﻿namespace Karage_Website.Models
{
    public class demoEmail
    {
        public string Name { get; set; }
        public string Email { get; set; }
        public string Phone { get; set; }
        public string Company { get; set; }
        public string CompanySize { get; set; }
        public string Position { get; set; }
    }
}
